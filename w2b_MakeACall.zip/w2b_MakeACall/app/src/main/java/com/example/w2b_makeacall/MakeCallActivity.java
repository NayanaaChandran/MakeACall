package com.example.w2b_makeacall;


import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class MakeCallActivity extends Activity implements View.OnClickListener {
    public static String TAG = "MakeACall";
    public EditText name;  //Android HTML Form Textfield to enter a phone number
    public String phone;
    private static final int MY_PERMISSIONS_REQUEST_CALL_PHONE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i(TAG, "NAYANA CHANDRAN 555555");
        Log.i(TAG, "OnCreate event handling; capture phone number");
        setContentView(R.layout.activity_main);

        // Event handling for the EXIT button from the MainActivity
        View exitButton = findViewById(R.id.exit_button);
        exitButton.setOnClickListener(this);
        Log.i(TAG, "You typed (onCreate): " + phone);
    }

    @Override
    public void onClick(View view) {
        //What is the source of the Click event(ie, the exit button)
        switch (view.getId()) {
            case R.id.exit_button:
                finish();
                break;
        }
    }

    //The APP will have an Options Menu

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true; //Acts like a Short Circuit as that the return value is ALWAYS TRUE
    }

    public void makePhoneCall(View view) {
        //Check if the app has the permission to make a call (AndroidManifest.xml)
        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);

        //Android will auto generate a Alert Dialog to the User asking him allow or deny the call to be made via dialer
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            // The CASE the PERMISSION is NOT GRANTED (!=)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, MY_PERMISSIONS_REQUEST_CALL_PHONE);
        } else {
            // The CASE the PERMISSION is GRANTED
            callPhone();
        }
    }

    //Assuming that the user has granted permission or allowed permission to make call, the dialer with the phone number
    // entered by the user earlier will be invoked
    private void callPhone() {
        //MainActivity layout field to capture a phone number from the user @Runtime
        EditText editText = (EditText) findViewById(R.id.phoneNumberEditTextId);
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.fromParts("tel.:",editText.getText().toString(),null));
         if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED){
            // ONLY in the case where the CALL_PHONE permission is GRANTED is the Activity
            // called. This is managed by the Runtime Permission Framework introduced
            // in Android 6.x Marshmallow (~v24)
            startActivity(intent);
        }
    }
}